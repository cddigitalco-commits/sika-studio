const WHATSAPP_NUMBER = "22957733365";
const form = document.getElementById("orderForm");
const pack = document.getElementById("pack");
const summary = document.getElementById("summary");

document.querySelectorAll(".choose").forEach(btn=>btn.addEventListener("click",()=>{pack.value=btn.dataset.pack;document.getElementById("commander").scrollIntoView({behavior:"smooth"});updateSummary();}));
function updateSummary(){const value=pack.value;if(!value){summary.textContent="Votre récapitulatif apparaîtra ici.";return;}let deposit="";if(value.includes("25 000"))deposit="12 500 FCFA";if(value.includes("45 000"))deposit="22 500 FCFA";if(value.includes("80 000"))deposit="40 000 FCFA";summary.innerHTML=`<strong>${value}</strong><br>Acompte de 50 % : <strong>${deposit}</strong><br>Solde à la livraison.`;}
pack.addEventListener("change",updateSummary);
form.addEventListener("submit",e=>{e.preventDefault();const data=new FormData(form);const message=`🚀 *NOUVELLE COMMANDE — SIKA STUDIO*\n\n*Nom :* ${data.get("name")}\n*WhatsApp :* ${data.get("phone")}\n*Produit :* ${data.get("product")}\n*Type :* ${data.get("type")}\n*Objectif :* ${data.get("goal")}\n*Pack :* ${data.get("pack")}\n*Lien produit :* ${data.get("link")||"Non fourni"}\n\n*BRIEF :*\n${data.get("brief")}\n\n*Paiement :* 50 % à la commande / 50 % à la livraison`;window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank");});
